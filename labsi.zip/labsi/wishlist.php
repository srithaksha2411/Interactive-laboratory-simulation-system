<?php
session_start();
include('config.php'); // Database connection

if (!isset($_SESSION['user_id'])) {
    die("You must be logged in to add to wishlist.");
}

$user_id = $_SESSION['user_id'];
$experiment_id = $_POST['experiment_id'];

// Check if already in wishlist
$check_query = "SELECT * FROM wishlist WHERE user_id = ? AND experiment_id = ?";
$stmt = $con->prepare($check_query);
$stmt->bind_param("ii", $user_id, $experiment_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    // Insert into wishlist
    $insert_query = "INSERT INTO wishlist (user_id, experiment_id, added_at) VALUES (?, ?, NOW())";
    $stmt = $con->prepare($insert_query);
    $stmt->bind_param("ii", $user_id, $experiment_id);
    if ($stmt->execute()) {
        echo "Added to wishlist!";
    } else {
        echo "Error: " . $stmt->error;
    }
} else {
    echo "Already in wishlist!";
}

$stmt->close();
$con->close();
?>
