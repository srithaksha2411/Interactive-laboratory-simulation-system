<?php
include('config.php');

// Get the search query from the GET request (if any)
$searchQuery = isset($_GET['search']) ? $_GET['search'] : '';

// Sanitize the input to prevent SQL injection
$searchQuery = mysqli_real_escape_string($con, $searchQuery);

// SQL query to fetch results based on the search query (category, sub-category, and title)
$query = "SELECT `id`, `category`, `sub_category`, `title`, `description`, `image_path`
          FROM `experiments`
          WHERE `category` LIKE '%$searchQuery%' 
             OR `sub_category` LIKE '%$searchQuery%' 
             OR `title` LIKE '%$searchQuery%'";

// Execute the query
$result = mysqli_query($con, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="keywords" content="Interactive Laboratory Simulation">
	<meta name="description" content="Search for laboratory experiments by category, subcategory, or title.">
	<title>Interactive Laboratory Simulation</title>
	<link rel="icon" type="image/png" sizes="56x56" href="images/fav-icon/icon.png">
	<link rel="stylesheet" type="text/css" href="css/style.css" media="all">
	<link rel="stylesheet" type="text/css" href="css/responsive.css" media="all">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="theme-color" content="#913BFF">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

	<!-- Add some custom styling for the search bar -->
	<style>
		.search-section {
			padding: 50px 0;
			background-color: #f9f9f9;
			text-align: center;
		}

		.search-bar {
			width: 60%;
			padding: 12px 25px;
			font-size: 16px;
			border-radius: 30px;
			border: 1px solid #ccc;
			outline: none;
			box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
			transition: all 0.3s ease-in-out;
		}

		.search-bar:focus {
			border-color: #913BFF;
			box-shadow: 0 4px 12px rgba(145, 59, 255, 0.3);
		}

		.search-bar::placeholder {
			color: #aaa;
		}

		.search-section h2 {
			font-size: 30px;
			color: #333;
			margin-bottom: 20px;
		}
	</style>
</head>

<body>
	<div class="main-page-wrapper">
		<?php include('header.php'); ?>
</br>
</br>
		<!-- Search Section -->
		<div class="search-section">
			<div class="container">
				<h2 class="intro-title">Search Laboratory Experiments</h2>
				<!-- Single Search Bar -->
				<input type="text" id="searchBar" class="search-bar" placeholder="Search by category, subcategory, or title" value="<?php echo $searchQuery; ?>">
			</div>
		</div>

		<!-- Theme Inner Banner -->
		<div class="theme-inner-banner">
			<div class="container">
				<h2 class="intro-title text-center">Search Results</h2>
				<ul class="page-breadcrumb style-none d-flex justify-content-center">
					<li><a href="index.html">Home</a></li>
					<li class="current-page">Search Results</li>
				</ul>
			</div>
		</div>

		<!-- Search Results Section -->
		<div class="fancy-feature-twentyFour">
			<div class="container">
				<div class="row gx-xxl-5" id="searchResults">
					<!-- Dynamic search results will be injected here -->
					<?php
					// Display results based on the query
					if (mysqli_num_rows($result) > 0) {
						while ($row = mysqli_fetch_assoc($result)) {
							echo "
							<div class='col-lg-4 col-sm-6 mb-40 xs-mb-30 d-flex' data-aos='fade-up'>
								<div class='block-style-four'>
									<div class='icon d-flex align-items-end justify-content-center'>
										<img src='labadmin/" . $row['image_path'] . "' alt=''>
									</div>
									<a href='experiment-details.php?id=" . $row['id'] . "'><h5>" . $row['title'] . "</h5></a>
									<p>" . $row['description'] . "</p>
									<a href='experiment-details.php?id=" . $row['id'] . "' class='more-btn'>
										<img src='images/icon/icon_13.svg' alt='' class='tran3s'>
									</a>
								</div>
							</div>
							";
						}
					} else {
						echo "<p>No experiments found for your search.</p>";
					}
					?>
				</div>
			</div>
		</div>

		<!-- Scroll to Top Button -->
		<button class="scroll-top">
			<i class="bi bi-arrow-up-short"></i>
		</button>
	</div>

	<!-- Optional JavaScript -->
	<script src="vendor/jquery.min.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
	<script src="vendor/aos-next/dist/aos.js"></script>
	<script src="vendor/slick/slick.min.js"></script>
	<script src="vendor/jquery.counterup.min.js"></script>
	<script src="vendor/jquery.waypoints.min.js"></script>
	<script src="vendor/fancybox/dist/jquery.fancybox.min.js"></script>
	<script src="js/theme.js"></script>

	<script>
		// This function fetches search results dynamically
		function fetchSearchResults(query) {
			$.ajax({
				url: "search_results.php", // The PHP file to fetch results
				type: "GET",
				data: { search: query },
				success: function(response) {
					$('#searchResults').html(response); // Inject the results
				}
			});
		}

		// Trigger search as the user types
		$('#searchBar').on('keyup', function() {
			var query = $(this).val(); // Get the value from the search bar
			fetchSearchResults(query); // Fetch results with the current query
		});
	</script>
</body>
</html>
