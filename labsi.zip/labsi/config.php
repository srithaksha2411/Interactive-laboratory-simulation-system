<?php
$server = "localhost";
$user = "root";
$password = "";
$database = "laboratory";

$con = mysqli_connect($server, $user, $password, $database);

if(!$con)
{
  echo "Connection Failed".mysqli_connect_error();
}
else
{
  //echo "Connected Successfully";
}
?>