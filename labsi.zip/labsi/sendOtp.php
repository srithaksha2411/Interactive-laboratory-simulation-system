<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get OTP and mobile number from POST data
    $otp = $_POST['otp'];
    $mobile = $_POST['mobile'];

    // Check if OTP or mobile is missing
    if (empty($otp) || empty($mobile)) {
        echo json_encode([
            'status' => 'error',
            'message' => 'OTP or Mobile number is missing.'
        ]);
        exit();  // Exit if data is invalid
    }

    // Save OTP to session
    session_start();
    $_SESSION['otp'] = $otp;

    // Create the WhatsApp message URL
    $whatsappMessage = 'Your OTP is ' . $otp;
    $whatsappLink = 'https://wa.me/91' . $mobile . '?text=' . urlencode($whatsappMessage);

    // Return a JSON response
    echo json_encode([
        'status' => 'success',
        'whatsapp_link' => $whatsappLink
    ]);
}
?>
