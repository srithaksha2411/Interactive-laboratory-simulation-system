<?php
session_start();

if(!$_SESSION['user_id'])
{
	header('location:logout.php');
}	
include('config.php'); 
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="keywords" content="Science, Experiments, Categories, User-Submitted, Research">
    <meta name="description" content="Explore science-based experiments shared by users across different categories. Search, filter, and engage with experiments easily.">
    <meta property="og:site_name" content="ScienceLab">
    <meta property="og:url" content="https://yourwebsite.com/">
    <meta property="og:type" content="website">
    <meta property="og:title" content="Explore Science Experiments">
    <meta name='og:image' content='images/logo.png'>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ScienceLab - Explore Science Experiments</title>
    <link rel="icon" type="image/png" sizes="56x56" href="images/fav-icon/icon.png">
    <link rel="stylesheet" type="text/css" href="css/style.css" media="all">
    <link rel="stylesheet" type="text/css" href="css/responsive.css" media="all">
    <style>
        /* Add any additional custom styles here */

        .hero-banner {
            background: url('banner.jpg') no-repeat center center;
            background-size: cover;
            padding: 100px 0;
            color: #fff;
			opacity: 0.9;
        }

        .hero-heading {
            font-size: 2.5rem;
            font-weight: bold;
            margin-bottom: 20px;
        }

        .hero-heading span {
            color: #913BFF;
        }

        .hero-banner .container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100%;
        }

        .button-group .demo-btn {
            background-color: #913BFF;
            padding: 12px 30px;
            border-radius: 30px;
            color: #fff;
            text-transform: uppercase;
            font-weight: bold;
            transition: 0.3s;
        }

        .button-group .demo-btn:hover {
            background-color: #6e27d2;
        }

        .experiment-card {
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            overflow: hidden;
            background-color: #fff;
            margin-bottom: 30px;
        }

        .experiment-card img {
            width: 100%;
            height: 200px;
            object-fit: cover;
        }

        .experiment-info {
            padding: 20px;
        }

        .experiment-title {
            font-size: 1.25rem;
            font-weight: 600;
            margin-bottom: 10px;
        }

        .experiment-description {
            font-size: 1rem;
            margin-bottom: 15px;
            color: #666;
        }

        .experiment-info .read-more-btn {
            background-color: #913BFF;
            color: #fff;
            padding: 8px 20px;
            border-radius: 4px;
            text-decoration: none;
        }

        .experiment-info .read-more-btn:hover {
            background-color: #6e27d2;
        }

        .search-experiments-section {
            padding: 60px 0;
            background-color: #f7f7f7;
        }

        .search-experiments-section h2 {
            text-align: center;
            margin-bottom: 30px;
            font-size: 2rem;
            color: #333;
        }

        .search-experiments-section form {
            text-align: center;
        }

        .search-experiments-section select,
        .search-experiments-section button {
            padding: 12px 20px;
            margin: 10px 5px;
            font-size: 1rem;
            border-radius: 5px;
        }

        .search-experiments-section select {
            border: 2px solid #ddd;
        }

        .search-experiments-section button {
            background-color: #913BFF;
            border: none;
            color: #fff;
            cursor: pointer;
        }

        .search-experiments-section button:hover {
            background-color: #6e27d2;
        }

    </style>
</head>

<body>
    <div class="main-page-wrapper">
        <!-- ===================================================
            Loading Transition
        ===================================================== -->

        <!-- 
        =============================================
            Search Section
        =============================================== 
        -->
        <div class="offcanvas offcanvas-top theme-search-form bg-three justify-content-center" tabindex="-1" id="offcanvasTop">
            <button type="button" class="close-btn tran3s" data-bs-dismiss="offcanvas" aria-label="Close"><i class="bi bi-x-lg"></i></button>
            <div class="form-wrapper">
                <form action="#">
                    <input type="text" placeholder="Search Experiments...">
                    <button type="submit">Search</button>
                </form>
            </div> <!-- /.form-wrapper -->
        </div>

        <!-- 
        =============================================
            Theme Main Menu
        =============================================== 
        -->
        <?php include('header.php'); ?>

        <!-- 
        =============================================
            Hero Banner Section
        =============================================== 
        -->
		</br>
        <div class="hero-banner">
            <div class="container">
                <div class="row">
                    <div class="col-xxl-6 col-md-7">
                        <h1 class="hero-heading">Explore Science Experiments <span>by Categories</span></h1>
                        <p class="text-lg mb-50 pt-40">Browse through a wide variety of science experiments shared by users. Search by category and find experiments that match your interest!</p>
                        <ul class="style-none button-group d-flex align-items-center">
                            <li class="me-4"><a href="#search-experiments" class="demo-btn ripple-btn tran3s">Browse Experiments</a></li>
                            <li><a class="fancybox video-icon tran3s" data-fancybox="" href="https://www.youtube.com/embed/aXFSJTjVjw0"><i class="fas fa-play"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div> <!-- /.container -->
        </div> <!-- /.hero-banner -->

        <!-- 
        =============================================
            Search & Filter Section
        =============================================== 
        -->
<div id="search-experiments" class="search-experiments-section">
    <div class="container">
        <h2 class="section-title">Search for Experiments by Categories</h2>
        <div class="row">
            <div class="col-md-6 offset-md-3">
                <form action="search.php" method="GET">
                    <div class="form-group">
                        <label for="category">Category</label>
                        <select name="category" id="category" class="form-control">
                            <option value="all">All Categories</option>
                            <?php
                                // Fetch categories from the database
                                

                                $sql = "SELECT CATEGORY_ID, CATEGORY FROM category";
                                $result = $con->query($sql);
                                while ($row = $result->fetch_assoc()) {
                                    echo "<option value='".$row['CATEGORY']."'>".$row['CATEGORY']."</option>";
                                }

                            ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="subcategory">Subcategory</label>
                        <select name="subcategory" id="subcategory" class="form-control">
                            <option value="all">Select a Category first</option>
                        </select>
                    </div>

                    <button type="submit" class="btn btn-primary">Search</button>
                </form>
            </div>
        </div>
    </div>
</div>


        <!-- 
        =============================================
            Experiment Display Section
        =============================================== 
        -->
        <div class="experiment-display-section">
    <div class="container">
        <h2 class="section-title">Featured Science Experiments</h2>
        <div class="row">
            <?php
            session_start();
            include('config.php'); // Database connection

            $user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;

            // Fetch experiments
            $query = "SELECT id, category, sub_category, title, description, image_path FROM experiments LIMIT 6";
            $result = mysqli_query($con, $query);

            if ($result && mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    ?>
                    <div class="col-md-4">
                        <div class="experiment-card">
                            <img src="labadmin/<?php echo $row['image_path']; ?>" alt="Experiment Image">
                            <div class="experiment-info">
                                <h3 class="experiment-title"><?php echo htmlspecialchars($row['title']); ?></h3>
                                <p class="experiment-description"><?php echo htmlspecialchars($row['description']); ?></p>
                                <a href="experiment-details.php?id=<?php echo $row['id']; ?>" class="read-more-btn">Read More</a>

                                <?php if ($user_id): ?>
                                    <form action="wishlist.php" method="POST" class="wishlist-form">
                                        <input type="hidden" name="experiment_id" value="<?php echo $row['id']; ?>">
                                        <button type="submit" class="wishlist-btn">❤️ Add to Wishlist</button>
                                    </form>
                                <?php else: ?>
                                    <p><a href="login.php">Login to add to wishlist</a></p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <?php
                }
            } else {
                echo "<p>No experiments found.</p>";
            }
            ?>
        </div>
    </div>
</div>


        <!--
        ======================================================
            Footer
        ======================================================
        -->
        

        <!-- Optional JavaScript _____________________________  -->
        <script src="vendor/jquery.min.js"></script>
        <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="vendor/aos-next/dist/aos.js"></script>
        <script src="vendor/slick/slick.min.js"></script>
        <script src="vendor/jquery.counterup.min.js"></script>
        <script src="vendor/jquery.waypoints.min.js"></script>
        <script src="vendor/fancybox/dist/jquery.fancybox.min.js"></script>
        <script src="js/theme.js"></script>
        <script>
    document.getElementById('category').addEventListener('change', function() {
        var categoryName = this.value;
        
        // Clear the subcategory dropdown
        var subcategoryDropdown = document.getElementById('subcategory');
        subcategoryDropdown.innerHTML = '<option value="all">Loading...</option>';

        if (categoryName !== 'all') {
            // Fetch subcategories based on selected category name
            var xhr = new XMLHttpRequest();
            xhr.open('GET', 'get_subcategories.php?category=' + encodeURIComponent(categoryName), true);
            xhr.onload = function() {
                if (xhr.status === 200) {
                    var subcategories = JSON.parse(xhr.responseText);
                    var subcategoryHTML = '<option value="all">Select Subcategory</option>';
                    
                    subcategories.forEach(function(subcategory) {
                        subcategoryHTML += '<option value="' + subcategory.SUBCATEGORY + '">' + subcategory.SUBCATEGORY + '</option>';
                    });

                    subcategoryDropdown.innerHTML = subcategoryHTML;
                }
            };
            xhr.send();
        } else {
            subcategoryDropdown.innerHTML = '<option value="all">Select a Category first</option>';
        }
    });
</script>

    </div> <!-- /.main-page-wrapper -->
</body>

</html>
