<?php
$category_name = $_GET['category']; // Now we're using category name instead of category_id

include('config.php');

// Query to select subcategories based on the category name
$sql = "SELECT SUBCAT_ID, CATEGORY, SUBCATEGORY FROM subcategory WHERE CATEGORY = ?";
$stmt = $con->prepare($sql);
$stmt->bind_param("s", $category_name); // 's' indicates string type for category name
$stmt->execute();
$result = $stmt->get_result();

$subcategories = [];
while ($row = $result->fetch_assoc()) {
    $subcategories[] = $row;
}

$stmt->close();
$con->close();

// Return the result as a JSON response
echo json_encode($subcategories);
?>
