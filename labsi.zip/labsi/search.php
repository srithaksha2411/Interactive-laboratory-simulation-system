<?php
include('config.php');


// Assuming you have the category and sub_category values from a GET request
$category = isset($_GET['category']) ? $_GET['category'] : '';
$sub_category = isset($_GET['sub_category']) ? $_GET['sub_category'] : '';

// Ensure to sanitize inputs to prevent SQL injection
$category = mysqli_real_escape_string($con, $category);
$sub_category = mysqli_real_escape_string($con, $sub_category);

// SQL query to fetch results based on category, sub-category, and search keyword
$query = "SELECT `id`, `category`, `sub_category`, `title`, `description`, `image_path`, `video_link`, `author_details`, `instruments`, `advantages`, `disadvantages`, `pros`, `cons`, `instrument_explanations`, `instrument_usage`, `created_at`
          FROM `experiments`
          WHERE `category` LIKE '%$category%' 
            AND `sub_category` LIKE '%$sub_category%'";

// Execute the query
$result = mysqli_query($con, $query);

?>
<!DOCTYPE html>
<html lang="en">
<head>
		<meta charset="UTF-8">
		<meta name="keywords" content="Data Science, Analytics, Data, sass, software company">
		<meta name="description" content="Sinco - Data Science & Analytics HTML5 Template is designed especially for the agency, multipurpose and business and those who offer business-related services.">
      	<meta property="og:site_name" content="Sinco">
      	<meta property="og:url" content="https://heloshape.com/">
      	<meta property="og:type" content="website">
      	<meta property="og:title" content="Sinco - Data Science & Analytics HTML5 Template">
		<meta name='og:image' content='images/assets/ogg.png'>
		<!-- For IE -->
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<!-- For Resposive Device -->
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<!-- For Window Tab Color -->
		<!-- Chrome, Firefox OS and Opera -->
		<meta name="theme-color" content="#913BFF">
		<!-- Windows Phone -->
		<meta name="msapplication-navbutton-color" content="#913BFF">
		<!-- iOS Safari -->
		<meta name="apple-mobile-web-app-status-bar-style" content="#913BFF">
		<title>Sinco - Data Science & Analytics HTML5 Template</title>
		<!-- Favicon -->
		<link rel="icon" type="image/png" sizes="56x56" href="images/fav-icon/icon.png">
		<!-- Main style sheet -->
		<link rel="stylesheet" type="text/css" href="css/style.css" media="all">
		<!-- responsive style sheet -->
		<link rel="stylesheet" type="text/css" href="css/responsive.css" media="all">

		<!-- Fix Internet Explorer ______________________________________-->
		<!--[if lt IE 9]>
			<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
			<script src="vendor/html5shiv.js"></script>
			<script src="vendor/respond.js"></script>
		<![endif]-->	
	</head>

	<body>
		<div class="main-page-wrapper">
			<!-- ===================================================
				Loading Transition
			==================================================== -->
			
			<!-- 
			=============================================
				Search
			============================================== 
			-->
			


			<!-- 
			=============================================
				Theme Main Menu
			============================================== 
			-->
			<?php include('header.php'); ?>
			 <!-- /.theme-main-menu -->


			
			<!-- 
			=============================================
				Theme Inner Banner
			============================================== 
			-->
			<div class="theme-inner-banner">
				<div class="container">
					<h2 class="intro-title text-center">Experiments</h2>
					<ul class="page-breadcrumb style-none d-flex justify-content-center">
						<li><a href="index.html">Home</a></li>
						<li class="current-page">Experiments</li>
					</ul>
				</div>
				<img src="images/shape/shape_38.svg" alt="" class="shapes shape-one">
				<img src="images/shape/shape_39.svg" alt="" class="shapes shape-two">
			</div> <!-- /.theme-inner-banner -->

			
			

			<!-- 
			=============================================
				Feature Section Twenty Four
			============================================== 
			-->
			<!-- Search Results Section -->
<div class="fancy-feature-twentyFour">
    <div class="container">
        <div class="row gx-xxl-5">
            <?php
            // Dynamically generate result blocks based on the fetched data
            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "
                    <div class='col-lg-4 col-sm-6 mb-40 xs-mb-30 d-flex' data-aos='fade-up'>
                        <div class='block-style-four'>
                            <div class='icon d-flex align-items-end justify-content-center'>
                                <img src='labadmin/" . $row['image_path'] . "' alt=''>
                            </div>
                            <a href='experiment-details.php?id=" . $row['id'] . "'><h5>" . $row['title'] . "</h5></a>
                            <p>" . $row['description'] . "</p>
                            <a href='experiment-details.php?id=" . $row['id'] . "' class='more-btn'>
                                <img src='images/icon/icon_13.svg' alt='' class='tran3s'>
                            </a>
                        </div> <!-- /.block-style-four -->
                    </div>
                    ";
                }
            } else {
                echo "<p>No services found for your search.</p>";
            }
            ?>
        </div>
    </div>
</div>
 <!-- /.fancy-feature-twentyFour -->



			<!-- 
			=============================================
				Feature Section Nineteen
			============================================== 
			-->
			 <!-- /.footer-style-four -->


			<button class="scroll-top">
				<i class="bi bi-arrow-up-short"></i>
			</button>
			
			


		<!-- Optional JavaScript _____________________________  -->

    	<!-- jQuery first, then Bootstrap JS -->
    	<!-- jQuery -->
		<script src="vendor/jquery.min.js"></script>
		<!-- Bootstrap JS -->
		<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
		<!-- AOS js -->
		<script src="vendor/aos-next/dist/aos.js"></script>
		<!-- Slick Slider -->
		<script src="vendor/slick/slick.min.js"></script>
		<!-- js Counter -->
		<script src="vendor/jquery.counterup.min.js"></script>
		<script src="vendor/jquery.waypoints.min.js"></script>
		<!-- Fancybox -->
		<script src="vendor/fancybox/dist/jquery.fancybox.min.js"></script>

		<!-- Theme js -->
		<script src="js/theme.js"></script>
		</div> <!-- /.main-page-wrapper -->
	</body>
</html>