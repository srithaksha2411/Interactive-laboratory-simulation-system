<?php
session_start();

include('config.php');
$experiment_id = $_GET['id'];
// Handle User Reviews
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['review'])) {
    if (!isset($_SESSION['user_id'])) {
        $error_message = "You must be logged in to submit a review.";
    } else {
        $user_id = $_SESSION['user_id'];
        // Example experiment ID
        $rating = intval($_POST['rating']);
        $comment = trim($_POST['comment']);

        if ($rating < 1 || $rating > 5) {
            $error_message = "Invalid rating.";
        } elseif (empty($comment)) {
            $error_message = "Please enter a comment.";
        } else {
            $stmt = $con->prepare("INSERT INTO reviews (user_id, experiment_id, rating, comment, created_at) VALUES (?, ?, ?, ?, NOW())");
            $stmt->bind_param("iiis", $user_id, $experiment_id, $rating, $comment);
            if ($stmt->execute()) {
                $success_message = "Review submitted!";
            } else {
                $error_message = "Error: " . $stmt->error;
            }
        }
    }
}

$fetch_reviews = $con->query("
    SELECT reviews.id, 
           users.username, 
           experiments.title, 
           reviews.rating, 
           reviews.comment, 
           reviews.created_at 
    FROM reviews 
    LEFT JOIN users ON reviews.user_id = users.id 
    LEFT JOIN experiments ON reviews.experiment_id = experiments.id
    WHERE reviews.experiment_id = $experiment_id
");

// Fetch experiment details from the database
  // Assuming the experiment id is passed as a URL parameter
$sql = "SELECT `id`, `category`, `sub_category`, `title`, `description`, `image_path`, `video_link`, `author_details`, `instruments`, `advantages`, `disadvantages`, `pros`, `cons`, `instrument_explanations`, `instrument_usage`, `created_at` 
        FROM `experiments` 
        WHERE `id` = $experiment_id";

$result = $con->query($sql);

if ($result->num_rows > 0) {
    // Fetch the experiment details
    $row = $result->fetch_assoc();
} else {
    echo "No experiment found.";
    exit;
}

$con->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="keywords" content="Data Science, Analytics, Data, sass, software company">
    <meta name="description" content="Sinco - Data Science & Analytics HTML5 Template is designed especially for the agency, multipurpose and business and those who offer business-related services.">
    <meta property="og:site_name" content="Sinco">
    <meta property="og:url" content="https://heloshape.com/">
    <meta property="og:type" content="website">
    <meta property="og:title" content="Sinco - Data Science & Analytics HTML5 Template">
    <meta name='og:image' content='images/assets/ogg.png'>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#913BFF">
    <meta name="msapplication-navbutton-color" content="#913BFF">
    <meta name="apple-mobile-web-app-status-bar-style" content="#913BFF">
    <title>Sinco - Data Science & Analytics HTML5 Template</title>
    <link rel="icon" type="image/png" sizes="56x56" href="images/fav-icon/icon.png">
    <link rel="stylesheet" type="text/css" href="css/style.css" media="all">
    <link rel="stylesheet" type="text/css" href="css/responsive.css" media="all">
</head>
<body>
    <div class="main-page-wrapper">
        <?php include('header.php'); ?>

        <div class="theme-inner-banner">
            <div class="container">
                <h2 class="intro-title"><?php echo $row['title']; ?><span></span></h2>
                <ul class="page-breadcrumb style-none d-flex">
                    <li><a href="index.html">Home</a></li>
                    <li class="current-page">Experiment Details</li>
                </ul>
            </div>
            <img src="images/assets/ils_20.svg" alt="" class="shapes illustration-two">
        </div>

        <div class="service-details position-relative mt-160 mb-150 lg-mt-100 lg-mb-100">
            <div class="container">
                <div class="row">
                    <div class="col-xl-9 col-lg-8 order-lg-1">
                        <div class="service-details-meta ps-lg-5 ms-xxl-4">
    <!-- Experiment Title -->
    <h2 class="main-title"><?php echo $row['title']; ?></h2>
    <p><strong>Category:</strong> <?php echo $row['category']; ?></p>
    <p><strong>Sub-Category:</strong> <?php echo $row['sub_category']; ?></p>

    <!-- Experiment Description -->
    <h3 class="sub-title">Description</h3>
    <p><?php echo $row['description']; ?></p>

    <!-- Experiment Image -->
    <img src="labadmin/<?php echo $row['image_path']; ?>" alt="Experiment Image" class="main-img-meta">

    <!-- Video Link -->
    <?php if (!empty($row['video_link'])): ?>
        <h3 class="sub-title">Video</h3>
        <div class="video-container">
            <iframe width="560" height="315" src="<?php echo $row['video_link']; ?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        </div>
    <?php endif; ?>

    <!-- Author Details -->
    <h3 class="sub-title">Author Details</h3>
    <p><?php echo $row['author_details']; ?></p>

    <!-- Instruments Used -->
    <h3 class="sub-title">Instruments</h3>
    <p><?php echo $row['instruments']; ?></p>

    <!-- Instrument Explanations -->
    <h3 class="sub-title">Instrument Explanations</h3>
    <p><?php echo $row['instrument_explanations']; ?></p>

    <!-- Advantages & Disadvantages Table -->
    <h3 class="sub-title">Advantages & Disadvantages</h3>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Advantages</th>
                <th>Disadvantages</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td><?php echo $row['advantages']; ?></td>
                <td><?php echo $row['disadvantages']; ?></td>
            </tr>
        </tbody>
    </table>

    <!-- Pros & Cons Table -->
    <h3 class="sub-title">Do's & Don'ts</h3>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Do's</th>
                <th>Don'ts</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td><?php echo $row['pros']; ?></td>
                <td><?php echo $row['cons']; ?></td>
            </tr>
        </tbody>
    </table>
</div>

                    </div>

                </div>
            </div>
            <img src="images/shape/shape_48.svg" alt="" class="shapes bg-shape">
        </div>
		<div class="review-form-wrapper">
            <h3>Leave a Review</h3>
            <form action="" method="POST">
                <input type="hidden" name="review" value="1">
                <label>Rating*</label>
                <select name="rating" required>
                    <option value="5">⭐⭐⭐⭐⭐</option>
                    <option value="4">⭐⭐⭐⭐</option>
                    <option value="3">⭐⭐⭐</option>
                    <option value="2">⭐⭐</option>
                    <option value="1">⭐</option>
                </select>
                <label>Comment*</label>
                <textarea name="comment" required></textarea>
                <button type="submit">Submit Review</button>
            </form>
        </div>

        <div class="reviews-section">
    <h3>Reviews</h3>
    <?php while ($row = $fetch_reviews->fetch_assoc()): ?>
        <div class="review-card">
            <strong><?= htmlspecialchars($row['username']) ?> reviewed "<?= htmlspecialchars($row['title']) ?>"</strong>
            <p>Rating: <?= str_repeat("⭐", $row['rating']) ?></p>
            <p><?= htmlspecialchars($row['comment']) ?></p>
            <small><?= date("F j, Y, g:i a", strtotime($row['created_at'])) ?></small>
        </div>
    <?php endwhile; ?>
</div>
    </div>

        

        <button class="scroll-top">
            <i class="bi bi-arrow-up-short"></i>
        </button>

        <script src="vendor/jquery.min.js"></script>
        <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="vendor/aos-next/dist/aos.js"></script>
        <script src="vendor/slick/slick.min.js"></script>
        <script src="vendor/jquery.counterup.min.js"></script>
        <script src="vendor/jquery.waypoints.min.js"></script>
        <script src="vendor/fancybox/dist/jquery.fancybox.min.js"></script>
        <script src="js/theme.js"></script>
    </div>
</body>
</html>
