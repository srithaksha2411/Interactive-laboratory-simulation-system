<?php
error_reporting(0);
session_start();
?>
<header class="theme-main-menu sticky-menu theme-menu-four">
				<div class="inner-content">
					<div class="d-flex align-items-center">
						<div class="logo order-lg-0"><a href="index.html" class="d-block">LABORATORY SIMULATION</div>

						<div class="right-widget d-flex align-items-center ms-auto order-lg-3">
							
							<a href="labadmin/" class="send-msg-btn tran3s d-none d-lg-block">Admin Login</a>
						</div> <!-- /.right-widget -->

						<nav class="navbar navbar-expand-lg order-lg-2">
							<button class="navbar-toggler d-block d-lg-none" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
						    	<span></span>
						 	</button>
						    <div class="collapse navbar-collapse" id="navbarNav">
						    	<ul class="navbar-nav">
						    		<li class="d-block d-lg-none"><div class="logo"><a href="index.html"><img src="images/logo/logo_01.png" alt="" width="130"></a></div></li>
							        <li class="nav-item active dropdown">
							        	<a class="nav-link" href="index.php" >Home</a>
						            </li>
									<li class="nav-item active dropdown">
							        	<a class="nav-link" href="search-result.php" >Search</a>
						            </li>
									<?php
									if($_SESSION['user_id'])
									{
									?>
									<li class="nav-item active dropdown">
							        	<a class="nav-link" href="logout.php" >Logout</a>
						            </li>
									<?php
									}
									?>
						            
						    	</ul>
						    	<!-- Mobile Content -->
						    	 <!-- /.mobile-content -->
						    </div>
						</nav>
					</div>
				</div> <!-- /.inner-content -->
			</header>