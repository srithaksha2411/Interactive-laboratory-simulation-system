<?php
include('config.php');

// Initialize filters
$fromDate = isset($_GET['fromDate']) ? $_GET['fromDate'] : '';
$toDate = isset($_GET['toDate']) ? $_GET['toDate'] : '';
$categoryFilter = isset($_GET['categoryFilter']) ? $_GET['categoryFilter'] : '';

// Fetch categories
$categoryQuery = "SELECT `CATEGORY_ID`, `CATEGORY`, `CATEGORY_UDATE` FROM `category`";
$categoryResult = $con->query($categoryQuery);

$categories = [];
if ($categoryResult->num_rows > 0) {
    while($row = $categoryResult->fetch_assoc()) {
        $categories[] = $row;
    }
}

// Build the base SQL query for experiments
$sql = "SELECT `id`, `category`, `sub_category`, `title`, `description`, `image_path`, `video_link`, `author_details`, `instruments`, `advantages`, `disadvantages`, `pros`, `cons`, `instrument_explanations`, `instrument_usage`, `created_at` FROM `experiments` WHERE 1";

// Apply filters if provided
if ($fromDate) {
    $sql .= " AND `created_at` >= '$fromDate'";
}
if ($toDate) {
    $sql .= " AND `created_at` <= '$toDate'";
}
if ($categoryFilter) {
    $sql .= " AND `category` = '$categoryFilter'";
}

// Execute the query
$experimentResult = $con->query($sql);

$experiments = [];
if ($experimentResult->num_rows > 0) {
    while($row = $experimentResult->fetch_assoc()) {
        $experiments[] = $row;
    }
}

$con->close();
?>

<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Date Wise Reports | Laboratory Simulation</title>
    <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.min.css">
    <link href="assets/vendor/fonts/circular-std/style.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/libs/css/style.css">
    <link rel="stylesheet" href="assets/vendor/fonts/fontawesome/css/fontawesome-all.css">
    <link rel="stylesheet" type="text/css" href="assets/vendor/datatables/css/dataTables.bootstrap4.css">
</head>

<body>
    <div class="dashboard-main-wrapper">
        <?php include 'header.php'; ?>
        <?php include 'sidebar.php'; ?>
        
        <div class="dashboard-wrapper">
            <div class="container-fluid dashboard-content">
                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="page-header">
                            <h2 class="pageheader-title">Reports</h2>
                            <div class="page-breadcrumb">
                                <nav aria-label="breadcrumb">
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">Reports</a></li>
                                        <li class="breadcrumb-item active" aria-current="page">Date Wise Reports</li>
                                    </ol>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="mb-0">Date Wise Reports Table</h5>
                            </div>
                            <div class="card-body">
                                <!-- Filter Section -->
                                <div class="row mb-4">
                                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 mb-2">
                                        <label for="fromDate">From Date</label>
                                        <input type="date" class="form-control" id="fromDate">
                                    </div>
                                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 mb-2">
                                        <label for="toDate">To Date</label>
                                        <input type="date" class="form-control" id="toDate">
                                    </div>
                                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 mb-2">
                                        <label for="categoryFilter">Category</label>
                                        <select class="form-control" id="categoryFilter">
                                            <option value="">Select Category</option>
                                            <?php foreach ($categories as $category) { ?>
                                                <option value="<?php echo $category['CATEGORY']; ?>"><?php echo $category['CATEGORY']; ?></option>
                                            <?php } ?>
                                        </select>
                                    </div>
                                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 text-right">
                                        <button class="btn btn-primary" type="button" id="filterButton">Filter</button>
                                    </div>
                                </div>

                                <div class="table-responsive">
                                    <table id="example" class="table table-striped table-bordered">
                                        <thead>
                                            <tr>
                                                <th>S.No</th>
                                                <th>Date</th>
                                                <th>Category Name</th>
                                                <th>Experiment Title</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($experiments as $index => $experiment) { 
                                                $date = date('Y-m-d', strtotime($experiment['created_at']));
                                            ?>
                                                <tr>
                                                    <td><?php echo $index + 1; ?></td>
                                                    <td><?php echo $date; ?></td>
                                                    <td><?php echo $experiment['category']; ?></td>
                                                    <td><?php echo $experiment['title']; ?></td>
                                                    <td>
                                                        <button class="btn btn-primary btn-sm">View</button>
                                                        <button class="btn btn-primary btn-sm">Edit</button>
                                                        <button class="btn btn-danger btn-sm">Delete</button>
                                                    </td>
                                                </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <?php include 'footer.php'; ?>
        </div>
    </div>

    <!-- JavaScript -->
    <script src="assets/vendor/jquery/jquery-3.3.1.min.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
    <script src="assets/vendor/slimscroll/jquery.slimscroll.js"></script>
    <script src="assets/libs/js/main-js.js"></script>
    
    <script>
        document.getElementById('filterButton').addEventListener('click', function() {
            const fromDate = document.getElementById('fromDate').value;
            const toDate = document.getElementById('toDate').value;
            const category = document.getElementById('categoryFilter').value;

            let url = window.location.pathname + '?';

            if (fromDate) {
                url += 'fromDate=' + fromDate + '&';
            }
            if (toDate) {
                url += 'toDate=' + toDate + '&';
            }
            if (category) {
                url += 'categoryFilter=' + category + '&';
            }

            window.location.href = url;
        });
    </script>
</body>

</html>
