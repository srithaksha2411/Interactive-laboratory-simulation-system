<?php
session_start();
include('config.php');

if (isset($_POST['submit'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Secure SQL with prepared statement
    $stmt = $con->prepare("SELECT * FROM admin WHERE ADMIN_UNAME = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    $value = $result->fetch_assoc();

    if ($value && $password == $value['ADMIN_PASS']) {
        $_SESSION['AID'] = $value['ADMIN_ID'];
        $_SESSION['ANAME'] = $value['ADMIN_UNAME'];
        header('location: index.php');
        exit;
    } else {
        echo "<script>alert('INVALID CREDENTIALS'); window.location.assign('login.php');</script>";
    }
}
?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Admin Login | Laboratory Simulation</title>
    
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.min.css">
    <link href="assets/vendor/fonts/circular-std/style.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/libs/css/style.css">
    <link rel="stylesheet" href="assets/vendor/fonts/fontawesome/css/fontawesome-all.css">
    
    <style>
        html, body {
            height: 100%;
            margin: 0;
            padding: 0;
            background: url('assets/images/image23.jpeg') no-repeat center center fixed;
            background-size: cover;
            font-family: 'Circular Std', sans-serif;
        }
        
        .splash-container {
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }

        .card {
            border: none;
            background: white;
            border-radius: 10px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
            width: 350px;
            overflow: hidden;
        }

        .card-header {
            border-bottom: none;
            padding: 20px 20px 0;
            background: transparent;
            text-align: center;
        }

        .card-header a {
            font-size: 24px;
            color: #3498db;
            text-decoration: none;
            font-weight: 600;
        }

        .splash-description {
            display: block;
            color: #666;
            margin: 10px 0 20px;
            font-size: 14px;
        }

        .divider {
            height: 1px;
            background: #eee;
            margin: 0 20px;
        }

        .card-body {
            padding: 20px;
        }

        .form-control {
            border-radius: 5px;
            padding: 12px 15px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
        }

        .btn-primary {
            background-color: #3498db;
            border: none;
            padding: 12px;
            font-weight: 600;
            width: 100%;
            border-radius: 5px;
        }

        .card-footer {
            background: transparent;
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
        }

        .footer-link {
            color: #3498db;
            text-decoration: none;
            font-size: 13px;
        }

        .footer-link:hover {
            text-decoration: underline;
        }
    </style>
</head>

<body>
    <div class="splash-container">
        <div class="card">
            <div class="card-header">
                <a href="#">Laboratory Simulation</a>
                <span class="splash-description">Please enter your valid information.</span>
            </div>
            
            <!-- Light Gray Divider -->
            <div class="divider"></div>
            
            <div class="card-body">
                <form method="post">
                    <div class="form-group">
                        <input class="form-control form-control-lg" type="text" placeholder="Username" name="username" autocomplete="off" required>
                    </div>
                    <div class="form-group">
                        <input class="form-control form-control-lg" type="password" placeholder="Password" name="password" required>
                    </div>
                    <button type="submit" name="submit" class="btn btn-primary">Sign in</button>
                </form>
            </div>
            
            <div class="card-footer">
                <a href="forgot-password.php" class="footer-link">Forgot Password</a>
                <a href="../" class="footer-link">Back to Home</a>
            </div>
        </div>
    </div>

    <!-- JavaScript -->
    <script src="assets/vendor/jquery/jquery-3.3.1.min.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
</body>

</html>