<?php
session_start();

if(!$_SESSION['AID'])
{
	header('location:logout.php');
	exit;
}

include('config.php');


$id = $_GET['did'];

$delete = mysqli_query($con,"DELETE FROM subcategory WHERE SUBCAT_ID='$id'");

if($delete)
{
  echo "<script>alert('Deleted Successfully');</script>";
  echo "<script>window.location.assign('manage-sub-category.php');</script>";
}
else
{
  echo "<script>alert('Something went wrong');</script>";
  echo "<script>window.location.assign('manage-sub-category.php');</script>";
}
?>