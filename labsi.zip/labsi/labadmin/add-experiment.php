<?php
session_start();

if(!$_SESSION['AID'])
{
	header('location:logout.php');
	exit;
}

include('config.php');



// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize and validate form data
    $category = mysqli_real_escape_string($con, $_POST['category']);
    $sub_category = mysqli_real_escape_string($con, $_POST['sub_category']);
    $title = mysqli_real_escape_string($con, $_POST['title']);
    $description = mysqli_real_escape_string($con, $_POST['description']);
    $author_details = mysqli_real_escape_string($con, $_POST['author_details']);
    $video_link = mysqli_real_escape_string($con, $_POST['video_link']);
    
    // Handle Image Upload
    $image_path = '';
    if (isset($_FILES['imageUpload']) && $_FILES['imageUpload']['error'] == 0) {
        $target_dir = "uploads/";
        $target_file = $target_dir . basename($_FILES["imageUpload"]["name"]);
        move_uploaded_file($_FILES["imageUpload"]["tmp_name"], $target_file);
        $image_path = $target_file;
    }

    // Serialize the arrays into comma-separated strings
    $instruments = isset($_POST['instruments']) ? implode(", ", $_POST['instruments']) : '';
    $advantages = isset($_POST['advantages']) ? implode(", ", $_POST['advantages']) : '';
    $disadvantages = isset($_POST['disadvantages']) ? implode(", ", $_POST['disadvantages']) : '';
    $pros = isset($_POST['pros']) ? implode(", ", $_POST['pros']) : '';
    $cons = isset($_POST['cons']) ? implode(", ", $_POST['cons']) : '';
    $instrument_explanations = isset($_POST['instrument_explanations']) ? implode(", ", $_POST['instrument_explanations']) : '';
    

    // SQL query to insert data into the experiments table
    $sql = "INSERT INTO experiments (category, sub_category, title, description, image_path, video_link, author_details, instruments, advantages, disadvantages, pros, cons, instrument_explanations) 
            VALUES ('$category', '$sub_category', '$title', '$description', '$image_path', '$video_link', '$author_details', '$instruments', '$advantages', '$disadvantages', '$pros', '$cons', '$instrument_explanations')";

    if ($con->query($sql) === TRUE) {
        echo "New experiment added successfully!";
    } else {
        echo "Error: " . $sql . "<br>" . $con->error;
    }
}
?>

<!-- HTML Form remains unchanged -->


<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Add Experiment | Laboratory Simulation</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.min.css">
    <link href="assets/vendor/fonts/circular-std/style.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/libs/css/style.css">
    <link rel="stylesheet" href="assets/vendor/fonts/fontawesome/css/fontawesome-all.css">
</head>

<body>
    <div class="dashboard-main-wrapper">
        <!-- Navbar -->
        <?php include 'header.php'; ?>
        <!-- Sidebar -->
        <?php include 'sidebar.php'; ?>

        <!-- Wrapper -->
        <div class="dashboard-wrapper">
            <div class="container-fluid dashboard-content">
                <!-- Page Header -->
                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="page-header">
                            <h2 class="pageheader-title">Add Experiment</h2>
                            <div class="page-breadcrumb">
                                <nav aria-label="breadcrumb">
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">Experiment</a></li>
                                        <li class="breadcrumb-item active" aria-current="page">Add Experiment</li>
                                    </ol>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Experiment Form -->
                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="card">
                            <h5 class="card-header">Add Experiment Form</h5>
                            <div class="card-body">
                                <form method="POST" enctype="multipart/form-data" class="needs-validation" novalidate>
                                    <div class="row">
                                        <!-- Select Category -->
                                        <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12 mb-3">
                                            <label for="selectCategory">Category</label>
                                            <select class="form-control" id="selectCategory" name="category" required>
                    <option value="">Select Category...</option>
                    <?php
                    // Fetch all categories from the category table
                    $category_query = mysqli_query($con, "SELECT CATEGORY FROM category");
                    while ($row = mysqli_fetch_assoc($category_query)) {
                        echo "<option value='{$row['CATEGORY']}'>{$row['CATEGORY']}</option>";
                    }
                    ?>
                </select>
                                            <div class="invalid-feedback">Please select a category.</div>
                                        </div>
                                        <!-- Select Sub-Category -->
                                        <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12 mb-3">
                                            <label for="selectSubCategory">Sub-category</label>
                                            <select class="form-control" id="selectSubCategory" name="sub_category" required>
                    <option value="">Select Sub-category...</option>
                </select>
                                            <div class="invalid-feedback">Please select a sub-category.</div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <!-- Experiment Title -->
                                        <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12 mb-3">
                                            <label for="title">Experiment Title</label>
                                            <input type="text" class="form-control" id="title" name="title" placeholder="Enter title" required>
                                            <div class="invalid-feedback">Please provide a title.</div>
                                        </div>
                                        <!-- Description -->
                                        <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12 mb-3">
                                            <label for="description">Description</label>
                                            <textarea class="form-control" id="description" name="description" placeholder="History About This.." rows="3" required></textarea>
                                            <div class="invalid-feedback">Please provide a description.</div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <!-- Image Upload -->
                                        <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12 mb-3">
                                            <label for="imageUpload">Image Upload</label>
                                            <input type="file" class="form-control" id="imageUpload" name="imageUpload" required>
                                            <div class="invalid-feedback">Please upload an image.</div>
                                        </div>
                                        <!-- Video Link -->
                                        <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12 mb-3">
                                            <label for="videoLink">Video Link</label>
                                            <input type="url" class="form-control" id="videoLink" name="video_link" placeholder="Paste video link" required>
                                            <div class="invalid-feedback">Please provide a valid video link.</div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <!-- Author Details -->
                                        <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12 mb-3">
                                            <label for="authorDetails">Author Details</label>
                                            <textarea class="form-control" id="authorDetails" name="author_details" placeholder="Enter author details" rows="3" required></textarea>
                                            <div class="invalid-feedback">Please provide author details.</div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <!-- Instruments Required -->
                                        <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12 mb-3">
                                            <label for="instruments">Instruments Required</label>
                                            <div id="instrumentsGroup">
                                                <input type="text" class="form-control mb-2" name="instruments[]">
                                            </div>
                                            <button type="button" class="btn btn-success btn-sm" onclick="addInstrumentInput()">+</button>
                                        </div>
                                        <!-- Advantages -->
                                        <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12 mb-3">
                                            <label for="advantages">Advantages</label>
                                            <div id="advantagesGroup">
                                                <input type="text" class="form-control mb-2" name="advantages[]">
                                            </div>
                                            <button type="button" class="btn btn-success btn-sm" onclick="addAdvantageInput()">+</button>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <!-- Disadvantages -->
                                        <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12 mb-3">
                                            <label for="disadvantages">Disadvantages</label>
                                            <div id="disadvantagesGroup">
                                                <input type="text" class="form-control mb-2" name="disadvantages[]">
                                            </div>
                                            <button type="button" class="btn btn-success btn-sm" onclick="addDisadvantageInput()">+</button>
                                        </div>
                                        <!-- Pros -->
                                        <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12 mb-3">
                                            <label for="pros">Pros</label>
                                            <div id="prosGroup">
                                                <input type="text" class="form-control mb-2" name="pros[]">
                                            </div>
                                            <button type="button" class="btn btn-success btn-sm" onclick="addProInput()">+</button>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <!-- Cons -->
                                        <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12 mb-3">
                                            <label for="cons">Cons</label>
                                            <div id="consGroup">
                                                <input type="text" class="form-control mb-2" name="cons[]">
                                            </div>
                                            <button type="button" class="btn btn-success btn-sm" onclick="addConInput()">+</button>
                                        </div>
                                        <!-- Instrument Explanation -->
                                        <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12 mb-3">
                                            <label for="instrumentExplanation">Instruments Explanation</label>
                                            <div id="instrumentExplanationGroup">
                                                <textarea class="form-control mb-2" name="instrument_explanations[]"></textarea>
                                            </div>
                                            <button type="button" class="btn btn-success btn-sm" onclick="addInstrumentExplanationInput()">+</button>
                                        </div>
                                    </div>

                                    <div class="form-row">
                                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 text-right">
                                            <button class="btn btn-primary" type="submit">Submit</button>
                                            <button class="btn btn-secondary" type="reset">Reset</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Footer -->
        <?php include 'footer.php'; ?>
    </div>

    <!-- Scripts -->
    <script src="assets/vendor/jquery/jquery-3.3.1.min.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
    <script src="assets/vendor/slimscroll/jquery.slimscroll.js"></script>
    <script src="assets/libs/js/main-js.js"></script>
    <script>
        // Function to add input fields dynamically
        function addInstrumentInput() {
            const group = document.getElementById('instrumentsGroup');
            const input = document.createElement('input');
            input.type = 'text';
            input.className = 'form-control mb-2';
            input.name = 'instruments[]';
            group.appendChild(input);
        }

        function addAdvantageInput() {
            const group = document.getElementById('advantagesGroup');
            const input = document.createElement('input');
            input.type = 'text';
            input.className = 'form-control mb-2';
            input.name = 'advantages[]';
            group.appendChild(input);
        }

        function addDisadvantageInput() {
            const group = document.getElementById('disadvantagesGroup');
            const input = document.createElement('input');
            input.type = 'text';
            input.className = 'form-control mb-2';
            input.name = 'disadvantages[]';
            group.appendChild(input);
        }

        function addProInput() {
            const group = document.getElementById('prosGroup');
            const input = document.createElement('input');
            input.type = 'text';
            input.className = 'form-control mb-2';
            input.name = 'pros[]';
            group.appendChild(input);
        }

        function addConInput() {
            const group = document.getElementById('consGroup');
            const input = document.createElement('input');
            input.type = 'text';
            input.className = 'form-control mb-2';
            input.name = 'cons[]';
            group.appendChild(input);
        }

        function addInstrumentExplanationInput() {
            const group = document.getElementById('instrumentExplanationGroup');
            const input = document.createElement('textarea');
            input.className = 'form-control mb-2';
            input.name = 'instrument_explanations[]';
            group.appendChild(input);
        }

        function addInstrumentUsageInput() {
            const group = document.getElementById('instrumentUsageGroup');
            const input = document.createElement('textarea');
            input.className = 'form-control mb-2';
            input.name = 'instrument_usage[]';
            group.appendChild(input);
        }
		
		
		// jQuery to handle change in Category dropdown
        $('#selectCategory').on('change', function () {
            var category = $(this).val();  // Get selected category value

            if (category) {
                // Make an AJAX request to fetch subcategories based on the selected category
                $.ajax({
                    url: 'fetch_subcategories.php', // The PHP script to fetch subcategories
                    type: 'POST',
                    data: { category: category },
                    dataType: 'json',
                    success: function (data) {
                        // Clear the previous subcategories
                        $('#selectSubCategory').html('<option value="">Select Sub-category...</option>');
                        
                        // Loop through the response and append subcategories to the dropdown
                        $.each(data, function (index, subcategory) {
                            $('#selectSubCategory').append('<option value="' + subcategory.SUBCAT_ID + '">' + subcategory.SUBCATEGORY + '</option>');
                        });
                    }
                });
            } else {
                // Clear the subcategory dropdown if no category is selected
                $('#selectSubCategory').html('<option value="">Select Sub-category...</option>');
            }
        });
    </script>
</body>

</html>
