<?php
session_start();

if(!$_SESSION['AID']) {
    header('location:logout.php');
    exit;
}

include('config.php');

// Check if the experiment ID is passed
if (isset($_GET['id'])) {
    $experiment_id = $_GET['id'];

    // SQL query to delete the experiment
    $sql = "DELETE FROM experiments WHERE id = '$experiment_id'";

    if ($con->query($sql) === TRUE) {
        echo "Experiment deleted successfully!";
        // Redirect to the list page or another page after deletion
        header("Location: manage-experiment.php");
    } else {
        echo "Error: " . $con->error;
    }
} else {
    echo "No experiment found to delete!";
}
?>
