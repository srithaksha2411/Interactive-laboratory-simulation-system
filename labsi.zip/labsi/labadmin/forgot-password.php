<?php
session_start();

include('config.php');


if(isset($_POST['forgot']))
{
	$email = $_POST['email'];
	$mobile = $_POST['mobile'];
	
	$check = mysqli_query($con,"SELECT * FROM admin WHERE ADMIN_EMAIL='$email' AND ADMIN_MOBILE='$mobile'");
	$chkcnt = mysqli_num_rows($check);
	$chkval = mysqli_fetch_array($check);
	$UID = $chkval['ADMIN_ID'];
	if($chkcnt > 0)
	{
		$_SESSION['FID'] = $UID;
		header('location:reset.php');
		exit;
	}
	else
	{
		echo "<script>alert('INVALID USER DETAILS')</script>";
		echo "<script>window.location.assign('login.php')</script>";
	}
}

?>
<!doctype html>
<html lang="en">
 
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Forgot Password | Laboratory Simulation</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.min.css">
    <link href="assets/vendor/fonts/circular-std/style.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/libs/css/style.css">
    <link rel="stylesheet" href="assets/vendor/fonts/fontawesome/css/fontawesome-all.css">
    <style>
    html,
    body {
        height: 100%;
    }

    body {
        display: -ms-flexbox;
        display: flex;
        -ms-flex-align: center;
        align-items: center;
        padding-top: 40px;
        padding-bottom: 40px;
    }
    </style>
</head>
<!-- ============================================================== -->
<!-- signup form  -->
<!-- ============================================================== -->

<body>
    <!-- ============================================================== -->
    <!-- signup form  -->
    <!-- ============================================================== -->
    <form class="splash-container" method="post">
        <div class="card">
            <div class="card-header">
                <h3 class="mb-1">Forgot Password</h3>
                <p>Please enter your information.</p>
            </div>
            <div class="card-body">
                <div class="form-group">
                    <input class="form-control form-control-lg" type="email" name="email" required="" placeholder="Registered E-mail" autocomplete="off" name="email">
                </div>
                <div class="form-group">
                    <input class="form-control form-control-lg" id="mob1" type="mobile" required="" placeholder="Registered Mobile No" name="mobile" maxlength="10" minlength="10">
                </div>
                
                <div class="form-group pt-2">
                    <button class="btn btn-block btn-primary" type="submit" name="forgot" >Proceed</button>
                </div>
                
                
            </div>
            <div class="card-footer bg-white">
                <p>Back to Home? <a href="login.php" class="text-secondary">Click Here.</a></p>
            </div>
			
        </div>
    </form>
</body>

 
</html>