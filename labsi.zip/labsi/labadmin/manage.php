<?php
session_start();

if (!$_SESSION['AID']) {
    header('location:logout.php');
    exit;
}

include('config.php');

// Fetch Users
$fetch_users = mysqli_query($con, "SELECT id, username, mobile, email, created_at, user_type FROM users");

// Fetch Wishlist
$fetch_wishlist = mysqli_query($con, "SELECT wishlist.id, users.username, experiments.title, wishlist.added_at 
                                      FROM wishlist 
                                      JOIN users ON wishlist.user_id = users.id
                                      JOIN experiments ON wishlist.experiment_id = experiments.id");

// Fetch Experiments
$fetch_experiments = mysqli_query($con, "SELECT id, category, sub_category, title, description, image_path, video_link, author_details, instruments, advantages, disadvantages, pros, cons, instrument_explanations, instrument_usage, created_at FROM experiments");

// Fetch Reviews
$fetch_reviews = mysqli_query($con, 
    "SELECT reviews.id, 
            COALESCE(users.username, 'Unknown User') AS username, 
            COALESCE(experiments.title, 'Unknown Experiment') AS title, 
            reviews.rating, 
            reviews.comment, 
            reviews.created_at 
     FROM reviews 
     LEFT JOIN users ON reviews.user_id = users.id 
     LEFT JOIN experiments ON reviews.experiment_id = experiments.id"
);
?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Manage Data | Laboratory Simulation</title>
    <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/libs/css/style.css">
    <link rel="stylesheet" type="text/css" href="assets/vendor/datatables/css/dataTables.bootstrap4.css">
</head>

<body>
    <div class="dashboard-main-wrapper">
        <?php include 'header.php'; ?>
        <?php include 'sidebar.php'; ?>

        <div class="dashboard-wrapper">
            <div class="container-fluid dashboard-content">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="page-header">
                            <h2 class="pageheader-title">Manage Data</h2>
                        </div>
                    </div>
                </div>

                <!-- Users Table -->
                <div class="row">
                    <div class="col-xl-12">
                        <div class="card">
                            <div class="card-header"><h5>User Details</h5></div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="usersTable" class="table table-striped table-bordered">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>Username</th>
                                                <th>Mobile</th>
                                                <th>Email</th>
                                                <th>User Type</th>
                                                <th>Registered At</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php while ($row = mysqli_fetch_assoc($fetch_users)) { ?>
                                                <tr>
                                                    <td><?php echo $row['id']; ?></td>
                                                    <td><?php echo htmlspecialchars($row['username']); ?></td>
                                                    <td><?php echo htmlspecialchars($row['mobile']); ?></td>
                                                    <td><?php echo htmlspecialchars($row['email']); ?></td>
                                                    <td><?php echo htmlspecialchars($row['user_type']); ?></td>
                                                    <td><?php echo $row['created_at']; ?></td>
                                                </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Wishlist Table -->
                <div class="row">
                    <div class="col-xl-12">
                        <div class="card">
                            <div class="card-header"><h5>Wishlist</h5></div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="wishlistTable" class="table table-striped table-bordered">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>User</th>
                                                <th>Experiment</th>
                                                <th>Added At</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php while ($row = mysqli_fetch_assoc($fetch_wishlist)) { ?>
                                                <tr>
                                                    <td><?php echo $row['id']; ?></td>
                                                    <td><?php echo htmlspecialchars($row['username']); ?></td>
                                                    <td><?php echo htmlspecialchars($row['title']); ?></td>
                                                    <td><?php echo $row['added_at']; ?></td>
                                                </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Experiments Table -->
                

                <!-- Reviews Table -->
                <div class="row">
                    <div class="col-xl-12">
                        <div class="card">
                            <div class="card-header"><h5>Reviews</h5></div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="reviewsTable" class="table table-striped table-bordered">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>User</th>
                                                <th>Experiment</th>
                                                <th>Rating</th>
                                                <th>Comment</th>
                                                <th>Created At</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php while ($row = mysqli_fetch_assoc($fetch_reviews)) { ?>
                                                <tr>
                                                    <td><?php echo $row['id']; ?></td>
                                                    <td><?php echo htmlspecialchars($row['username']); ?></td>
                                                    <td><?php echo htmlspecialchars($row['title']); ?></td>
                                                    <td><?php echo $row['rating']; ?>/5</td>
                                                    <td><?php echo htmlspecialchars($row['comment']); ?></td>
                                                    <td><?php echo $row['created_at']; ?></td>
                                                </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
            <?php include 'footer.php'; ?>
        </div>
    </div>

    <script src="assets/vendor/jquery/jquery-3.3.1.min.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
    <script src="assets/vendor/datatables/js/dataTables.bootstrap4.min.js"></script>
</body>

</html>
