<?php
include('config.php');

// Check if category is set
if(isset($_POST['category'])) {
    $category = mysqli_real_escape_string($con, $_POST['category']);
    
    // Query to fetch subcategories based on the category
    $query = "SELECT SUBCAT_ID, SUBCATEGORY FROM subcategory WHERE CATEGORY = '$category'";
    $result = mysqli_query($con, $query);
    
    // Prepare an array to hold subcategories
    $subcategories = [];
    
    // Fetch the subcategories
    while($row = mysqli_fetch_assoc($result)) {
        $subcategories[] = $row;
    }
    
    // Return the subcategories as a JSON response
    echo json_encode($subcategories);
}
?>
