<?php 
session_start();  
if(!$_SESSION['AID']) {  
    header('location:logout.php');  
    exit; 
}  
include('config.php');  

// Fetch experiment ID from URL
$experiment_id = $_GET['id'];

// Fetch existing data from the database
$query = "SELECT * FROM experiments WHERE id = '$experiment_id'";
$result = mysqli_query($con, $query);
$row = mysqli_fetch_assoc($result);

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize and validate form data
    $category = mysqli_real_escape_string($con, $_POST['category']);
    $sub_category = mysqli_real_escape_string($con, $_POST['sub_category']);
    $title = mysqli_real_escape_string($con, $_POST['title']);
    $description = mysqli_real_escape_string($con, $_POST['description']);
    $author_details = mysqli_real_escape_string($con, $_POST['author_details']);
    $video_link = mysqli_real_escape_string($con, $_POST['video_link']);

    // Handle Image Upload
    $image_path = $row['image_path'];  // Keep existing image if no new one is uploaded
    if (isset($_FILES['imageUpload']) && $_FILES['imageUpload']['error'] == 0) {
        $target_dir = "uploads/";
        $target_file = $target_dir . basename($_FILES["imageUpload"]["name"]);
        move_uploaded_file($_FILES["imageUpload"]["tmp_name"], $target_file);
        $image_path = $target_file;  // Update image path if new image is uploaded
    }

    // Serialize arrays into comma-separated strings
    $instruments = isset($_POST['instruments']) ? implode(", ", $_POST['instruments']) : '';
    $advantages = isset($_POST['advantages']) ? implode(", ", $_POST['advantages']) : '';
    $disadvantages = isset($_POST['disadvantages']) ? implode(", ", $_POST['disadvantages']) : '';
    $pros = isset($_POST['pros']) ? implode(", ", $_POST['pros']) : '';
    $cons = isset($_POST['cons']) ? implode(", ", $_POST['cons']) : '';
    $instrument_explanations = isset($_POST['instrument_explanations']) ? implode(", ", $_POST['instrument_explanations']) : '';

    // SQL query to update data in the experiments table
    $sql = "UPDATE experiments 
            SET category='$category', sub_category='$sub_category', title='$title', description='$description', 
                image_path='$image_path', video_link='$video_link', author_details='$author_details', 
                instruments='$instruments', advantages='$advantages', disadvantages='$disadvantages', 
                pros='$pros', cons='$cons', instrument_explanations='$instrument_explanations'
            WHERE id='$experiment_id'";

    if ($con->query($sql) === TRUE) {
        echo "Experiment updated successfully!";
    } else {
        echo "Error: " . $sql . "<br>" . $con->error;
    }
}
?>

<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Edit Experiment | Laboratory Simulation</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.min.css">
    <link href="assets/vendor/fonts/circular-std/style.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/libs/css/style.css">
    <link rel="stylesheet" href="assets/vendor/fonts/fontawesome/css/fontawesome-all.css">
</head>

<body>
    <div class="dashboard-main-wrapper">
        <!-- Navbar -->
        <?php include 'header.php'; ?>
        <!-- Sidebar -->
        <?php include 'sidebar.php'; ?>

        <!-- Wrapper -->
        <div class="dashboard-wrapper">
            <div class="container-fluid dashboard-content">
                <!-- Page Header -->
                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="page-header">
                            <h2 class="pageheader-title">Edit Experiment</h2>
                            <div class="page-breadcrumb">
                                <nav aria-label="breadcrumb">
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">Experiment</a></li>
                                        <li class="breadcrumb-item active" aria-current="page">Edit Experiment</li>
                                    </ol>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Edit Experiment Form -->
                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="card">
                            <h5 class="card-header">Edit Experiment Form</h5>
                            <div class="card-body">
                                <form method="POST" enctype="multipart/form-data" class="needs-validation" novalidate>
                                    <div class="row">
                                        <!-- Select Category -->
                                        <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12 mb-3">
                                            <label for="selectCategory">Category</label>
                                            <select class="form-control" id="selectCategory" name="category" required>
                                                <option value="">Select Category...</option>
                                                <?php
                                                // Fetch all categories from the category table
                                                $category_query = mysqli_query($con, "SELECT CATEGORY FROM category");
                                                while ($row_cat = mysqli_fetch_assoc($category_query)) {
                                                    // Check if the category matches the existing one
                                                    $selected = $row_cat['CATEGORY'] == $row['category'] ? 'selected' : '';
                                                    echo "<option value='{$row_cat['CATEGORY']}' {$selected}>{$row_cat['CATEGORY']}</option>";
                                                }
                                                ?>
                                            </select>
                                            <div class="invalid-feedback">Please select a category.</div>
                                        </div>
                                        <!-- Select Sub-Category -->
                                        <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12 mb-3">
                                            <label for="selectSubCategory">Sub-category</label>
                                            <select class="form-control" id="selectSubCategory" name="sub_category" required>
                                                <option value="">Select Sub-category...</option>
                                                <?php
                                                // Fetch subcategories based on category selected
                                                $subcat_query = mysqli_query($con, "SELECT SUBCAT_ID, SUBCATEGORY FROM subcategory WHERE CATEGORY = '{$row['category']}'");
                                                while ($row_subcat = mysqli_fetch_assoc($subcat_query)) {
                                                    // Check if subcategory matches the existing one
                                                    $selected = $row_subcat['SUBCATEGORY'] == $row['sub_category'] ? 'selected' : '';
                                                    echo "<option value='{$row_subcat['SUBCATEGORY']}' {$selected}>{$row_subcat['SUBCATEGORY']}</option>";
                                                }
                                                ?>
                                            </select>
                                            <div class="invalid-feedback">Please select a sub-category.</div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <!-- Experiment Title -->
                                        <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12 mb-3">
                                            <label for="title">Experiment Title</label>
                                            <input type="text" class="form-control" id="title" name="title" value="<?= $row['title']; ?>" placeholder="Enter title" required>
                                            <div class="invalid-feedback">Please provide a title.</div>
                                        </div>
                                        <!-- Description -->
                                        <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12 mb-3">
                                            <label for="description">Description</label>
                                            <textarea class="form-control" id="description" name="description" placeholder="History About This.." rows="3" required><?= $row['description']; ?></textarea>
                                            <div class="invalid-feedback">Please provide a description.</div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <!-- Image Upload -->
                                        <!-- Image Upload -->
<div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12 mb-3">
    <label for="imageUpload">Image Upload</label>
    <input type="file" class="form-control" id="imageUpload" name="imageUpload">
    <div class="invalid-feedback">Please upload an image.</div>
    
    <!-- Display previously uploaded image -->
    <?php if (!empty($row['image_path'])): ?>
        <div class="mt-3">
            <p>Currently uploaded image:</p>
            <img src="<?= $row['image_path']; ?>" alt="Experiment Image" class="img-fluid" style="max-width: 100%; height: auto;">
        </div>
    <?php endif; ?>
</div>

                                        <!-- Video Link -->
                                        <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12 mb-3">
                                            <label for="videoLink">Video Link</label>
                                            <input type="url" class="form-control" id="videoLink" name="video_link" value="<?= $row['video_link']; ?>" placeholder="Paste video link" required>
                                            <div class="invalid-feedback">Please provide a valid video link.</div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <!-- Author Details -->
                                        <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12 mb-3">
                                            <label for="authorDetails">Author Details</label>
                                            <textarea class="form-control" id="authorDetails" name="author_details" placeholder="Enter author details" rows="3" required><?= $row['author_details']; ?></textarea>
                                            <div class="invalid-feedback">Please provide author details.</div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <!-- Instruments Required -->
                                        <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12 mb-3">
                                            <label for="instruments">Instruments Required</label>
                                            <div id="instrumentsGroup">
                                                <?php
                                                // Populate instruments with existing values
                                                $instruments = explode(", ", $row['instruments']);
                                                foreach ($instruments as $instrument) {
                                                    echo "<input type='text' class='form-control mb-2' name='instruments[]' value='$instrument'>";
                                                }
                                                ?>
                                            </div>
                                            <button type="button" class="btn btn-success btn-sm" onclick="addInstrumentInput()">+</button>
                                        </div>
										<!-- Instrument Explanations -->
<div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12 mb-3">
    <label for="instrument_explanations">Instrument Explanations</label>
    <div id="instrumentExplanationsGroup">
        <?php
        // Populate instrument explanations with existing values
        $instrument_explanations = explode(", ", $row['instrument_explanations']);
        foreach ($instrument_explanations as $explanation) {
            echo "<input type='text' class='form-control mb-2' name='instrument_explanations[]' value='$explanation'>";
        }
        ?>
    </div>
    <button type="button" class="btn btn-success btn-sm" onclick="addInstrumentExplanationInput()">+</button>
</div>

                                        <!-- Advantages -->
                                        <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12 mb-3">
                                            <label for="advantages">Advantages</label>
                                            <div id="advantagesGroup">
                                                <?php
                                                // Populate advantages with existing values
                                                $advantages = explode(", ", $row['advantages']);
                                                foreach ($advantages as $advantage) {
                                                    echo "<input type='text' class='form-control mb-2' name='advantages[]' value='$advantage'>";
                                                }
                                                ?>
                                            </div>
                                            <button type="button" class="btn btn-success btn-sm" onclick="addAdvantageInput()">+</button>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <!-- Disadvantages -->
                                        <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12 mb-3">
                                            <label for="disadvantages">Disadvantages</label>
                                            <div id="disadvantagesGroup">
                                                <?php
                                                // Populate disadvantages with existing values
                                                $disadvantages = explode(", ", $row['disadvantages']);
                                                foreach ($disadvantages as $disadvantage) {
                                                    echo "<input type='text' class='form-control mb-2' name='disadvantages[]' value='$disadvantage'>";
                                                }
                                                ?>
                                            </div>
                                            <button type="button" class="btn btn-success btn-sm" onclick="addDisadvantageInput()">+</button>
                                        </div>
                                    </div>
									
									<div class="row">
    <!-- Pros -->
    <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12 mb-3">
        <label for="pros">Pros</label>
        <div id="prosGroup">
            <?php
            // Populate pros with existing values
            $pros = explode(", ", $row['pros']);
            foreach ($pros as $pro) {
                echo "<input type='text' class='form-control mb-2' name='pros[]' value='$pro'>";
            }
            ?>
        </div>
        <button type="button" class="btn btn-success btn-sm" onclick="addProInput()">+</button>
    </div>
    <!-- Cons -->
    <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12 mb-3">
        <label for="cons">Cons</label>
        <div id="consGroup">
            <?php
            // Populate cons with existing values
            $cons = explode(", ", $row['cons']);
            foreach ($cons as $con) {
                echo "<input type='text' class='form-control mb-2' name='cons[]' value='$con'>";
            }
            ?>
        </div>
        <button type="button" class="btn btn-success btn-sm" onclick="addConInput()">+</button>
    </div>
</div>

                                    <div class="form-row">
                                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 text-right">
                                            <button class="btn btn-primary" type="submit">Submit</button>
                                            <button class="btn btn-secondary" type="reset">Reset</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Footer -->
        <?php include 'footer.php'; ?>
    </div>

    <!-- Scripts -->
    <script src="assets/vendor/jquery/jquery-3.3.1.min.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
    <script src="assets/vendor/slimscroll/jquery.slimscroll.js"></script>
    <script src="assets/libs/js/main-js.js"></script>
    <script>
        // Function to add input fields dynamically
        function addInstrumentInput() {
            const group = document.getElementById('instrumentsGroup');
            const input = document.createElement('input');
            input.type = 'text';
            input.className = 'form-control mb-2';
            input.name = 'instruments[]';
            group.appendChild(input);
        }

        function addAdvantageInput() {
            const group = document.getElementById('advantagesGroup');
            const input = document.createElement('input');
            input.type = 'text';
            input.className = 'form-control mb-2';
            input.name = 'advantages[]';
            group.appendChild(input);
        }

        function addDisadvantageInput() {
            const group = document.getElementById('disadvantagesGroup');
            const input = document.createElement('input');
            input.type = 'text';
            input.className = 'form-control mb-2';
            input.name = 'disadvantages[]';
            group.appendChild(input);
        }
		
		function addProInput() {
    const group = document.getElementById('prosGroup');
    const input = document.createElement('input');
    input.type = 'text';
    input.className = 'form-control mb-2';
    input.name = 'pros[]';
    group.appendChild(input);
}

function addConInput() {
    const group = document.getElementById('consGroup');
    const input = document.createElement('input');
    input.type = 'text';
    input.className = 'form-control mb-2';
    input.name = 'cons[]';
    group.appendChild(input);
}

function addInstrumentExplanationInput() {
    const group = document.getElementById('instrumentExplanationsGroup');
    const input = document.createElement('input');
    input.type = 'text';
    input.className = 'form-control mb-2';
    input.name = 'instrument_explanations[]';
    group.appendChild(input);
}

    </script>
</body>
</html>
