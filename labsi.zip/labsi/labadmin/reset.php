<?php
session_start();

include('config.php');

if(isset($_POST['reset']))
{
	
	$passw=$_POST['cpass'];
	
	$reset=mysqli_query($con,"UPDATE admin SET ADMIN_PASS='$passw' WHERE ADMIN_ID='$_SESSION[FID]'");
	if($reset)
	{
		echo "<script>alert('Reset Successfully')</script>";
		echo "<script>window.location.assign('logout.php')</script>";
	}
	else
	{
		echo "<script>alert('Invalid Credentials')</script>";
		echo "<script>window.location.assign('login.php')</script>";
	}
}
?>
<!doctype html>
<html lang="en">
 
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Forgot Password | Laboratory Simulation</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.min.css">
    <link href="assets/vendor/fonts/circular-std/style.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/libs/css/style.css">
    <link rel="stylesheet" href="assets/vendor/fonts/fontawesome/css/fontawesome-all.css">
    <style>
    html,
    body {
        height: 100%;
    }

    body {
        display: -ms-flexbox;
        display: flex;
        -ms-flex-align: center;
        align-items: center;
        padding-top: 40px;
        padding-bottom: 40px;
    }
    </style>
</head>
<!-- ============================================================== -->
<!-- signup form  -->
<!-- ============================================================== -->

<body>
    <!-- ============================================================== -->
    <!-- signup form  -->
    <!-- ============================================================== -->
    <form class="splash-container" method="post">
        <div class="card">
            <div class="card-header">
                <h3 class="mb-1">Reset Password</h3>
            </div>
            <div class="card-body">
                <div class="form-group">
                    <input class="form-control form-control-lg" id="mob1" type="password" required="" placeholder="New Password" name="cpass">
                </div>
                
                <div class="form-group pt-2">
                    <button class="btn btn-block btn-primary" type="submit" name="reset" >Reset</button>
                </div>
                
                
            </div>
            <div class="card-footer bg-white">
                <p>Back to Home? <a href="login.php" class="text-secondary">Click Here.</a></p>
            </div>
			
        </div>
    </form>
</body>

 
</html>