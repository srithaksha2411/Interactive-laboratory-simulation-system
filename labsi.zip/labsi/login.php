<?php
session_start();
include('config.php'); // Include your database connection file

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Query to fetch user data based on email
    $sql = "SELECT `id`, `username`, `mobile`, `email`, `password`, `created_at` FROM `users` WHERE email = '$email'";
    $result = $con->query($sql);

    // Check if the email exists in the database
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();

        // Check if the password matches
        if ($password == $row['password']) {
            // If valid credentials, store user info in session
            $_SESSION['user_id'] = $row['id'];
            $_SESSION['username'] = $row['username'];
            $_SESSION['email'] = $row['email'];

            // Redirect to a dashboard or home page
            header("Location: index.php");
            exit();
        } else {
            $error_message = "Incorrect password!";
        }
    } else {
        $error_message = "No user found with this email!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="keywords" content="Data Science, Analytics, Data, sass, software company">
    <meta name="description" content="Sinco - Data Science & Analytics HTML5 Template is designed especially for the agency, multipurpose and business and those who offer business-related services.">
    <meta property="og:site_name" content="Sinco">
    <meta property="og:url" content="https://heloshape.com/">
    <meta property="og:type" content="website">
    <meta property="og:title" content="Sinco - Data Science & Analytics HTML5 Template">
    <meta name='og:image' content='images/assets/ogg.png'>
    <!-- For IE -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- For Resposive Device -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- For Window Tab Color -->
    <!-- Chrome, Firefox OS and Opera -->
    <meta name="theme-color" content="#913BFF">
    <!-- Windows Phone -->
    <meta name="msapplication-navbutton-color" content="#913BFF">
    <!-- iOS Safari -->
    <meta name="apple-mobile-web-app-status-bar-style" content="#913BFF">
    <title>LABORATORY - Login Page</title>
    <!-- Favicon -->
    <link rel="icon" type="image/png" sizes="56x56" href="images/fav-icon/icon.png">
    <!-- Main style sheet -->
    <link rel="stylesheet" type="text/css" href="css/style.css" media="all">
    <!-- responsive style sheet -->
    <link rel="stylesheet" type="text/css" href="css/responsive.css" media="all">
</head>

<body>
    <div class="main-page-wrapper">
        <!-- ===================================================
            Loading Transition
        ===================================================== -->
       

        <!-- 
        ==============================================
            Sign In
        =============================================== 
        -->
        <div class="user-data-page clearfix d-md-flex">
             <!-- /.illustration-wrapper -->

            <div class="form-wrapper">
                <div class="d-flex justify-content-between align-items-center">
                    <div class="logo"><a href="index.html" class="d-block"><img src="images/logo/logo_01.png" alt="" width="131"></a></div>
                    <a href="index.php" class="go-back-button tran3s">Go to home</a>
                </div>
                <form action="" method="POST" class="user-data-form mt-60 lg-mt-40">
                    <h2>Hi buddy, welcome <br> Back!</h2>
                    <p class="header-info pt-20 pb-20 lg-pt-10 lg-pb-10">Still don't have an account? <a href="signup.php">Sign up</a></p>

                    <div class="row">
                        <div class="col-12">
                            <div class="input-group-meta mb-25">
                                <label>Email</label>
                                <input type="email" name="email" placeholder="rshdkabir@gmail.com" required>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="input-group-meta mb-25">
                                <label>Password</label>
                                <input type="password" name="password" placeholder="Enter Password" class="pass_log_id" required>
                                <span class="placeholder_icon"><span class="passVicon"><img src="images/icon/icon_40.svg" alt=""></span></span>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="agreement-checkbox d-flex justify-content-between align-items-center">
                                <div>
                                    <input type="checkbox" id="remember">
                                    <label for="remember">Keep me logged in</label>
                                </div>
                                <a href="signup.php">Sign up</a>
                            </div> <!-- /.agreement-checkbox -->
                        </div>
                        <div class="col-12">
                            <button class="btn-eight w-100 mt-50 mb-40 lg-mt-30 lg-mb-30" type="submit">Login</button>
                        </div>
                        <div class="col-12">
                            <?php
                            // Display error message if credentials are incorrect
                            if (isset($error_message)) {
                                echo "<p style='color: red;'>{$error_message}</p>";
                            }
                            ?>
                            <p class="text-center copyright-text m0">Copyright @2022 sinco inc.</p>
                        </div>
                    </div>
                </form>
            </div> <!-- /.form-wrapper -->
        </div> <!-- /.user-data-page -->

        <button class="scroll-top">
            <i class="bi bi-arrow-up-short"></i>
        </button>
    </div> <!-- /.main-page-wrapper -->

    <!-- Optional JavaScript _____________________________  -->
    <!-- jQuery first, then Bootstrap JS -->
    <!-- jQuery -->
    <script src="vendor/jquery.min.js"></script>
    <!-- Bootstrap JS -->
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- AOS js -->
    <script src="vendor/aos-next/dist/aos.js"></script>
    <!-- Slick Slider -->
    <script src="vendor/slick/slick.min.js"></script>
    <!-- js Counter -->
    <script src="vendor/jquery.counterup.min.js"></script>
    <script src="vendor/jquery.waypoints.min.js"></script>
    <!-- Fancybox -->
    <script src="vendor/fancybox/dist/jquery.fancybox.min.js"></script>
    <!-- isotop -->
    <script  src="vendor/isotope.pkgd.min.js"></script>

    <!-- Theme js -->
    <script src="js/theme.js"></script>
</body>

</html>
