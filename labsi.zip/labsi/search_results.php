<?php
include('config.php');

// Get the search query from the GET request
$searchQuery = isset($_GET['search']) ? $_GET['search'] : '';

// Sanitize the input to prevent SQL injection
$searchQuery = mysqli_real_escape_string($con, $searchQuery);

// SQL query to fetch results based on the search query (category, sub-category, and title)
$query = "SELECT `id`, `category`, `sub_category`, `title`, `description`, `image_path`
          FROM `experiments`
          WHERE `category` LIKE '%$searchQuery%' 
             OR `sub_category` LIKE '%$searchQuery%' 
             OR `title` LIKE '%$searchQuery%'";

// Execute the query
$result = mysqli_query($con, $query);

// Generate the HTML for the search results
if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        echo "
        <div class='col-lg-4 col-sm-6 mb-40 xs-mb-30 d-flex' data-aos='fade-up'>
            <div class='block-style-four'>
                <div class='icon d-flex align-items-end justify-content-center'>
                    <img src='labadmin/" . $row['image_path'] . "' alt=''>
                </div>
                <a href='experiment-details.php?id=" . $row['id'] . "'><h5>" . $row['title'] . "</h5></a>
                <p>" . $row['description'] . "</p>
                <a href='experiment-details.php?id=" . $row['id'] . "' class='more-btn'>
                    <img src='images/icon/icon_13.svg' alt='' class='tran3s'>
                </a>
            </div>
        </div>
        ";
    }
} else {
    echo "<p>No experiments found for your search.</p>";
}
?>
