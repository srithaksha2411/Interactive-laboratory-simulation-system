<?php
session_start();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Register the user after OTP verification
    if (isset($_POST['verify_otp'])) {
        // Retrieve POST data
        $enteredOtp = $_POST['otp'];
        $mobile = $_POST['mobile'];
        $name = $_POST['name'];
        $email = $_POST['email'];
        $userType = $_POST['user_type'];
        $password = $_POST['password']; // Password entered by user
        $confirmPassword = $_POST['confirm_password']; // Confirm Password entered by user

        // Validate the OTP
        if ($_SESSION['otp'] !== $enteredOtp) {
            $error_message = "Invalid OTP. Please try again.";
        } elseif ($password !== $confirmPassword) {
            // Check if password and confirm password match
            $error_message = "Password and Confirm Password do not match.";
        } else {
            // Hash the password before storing it
            $hashedPassword = $password;

            // Proceed with registration (Insert into database)
            include('config.php');
            $query = "INSERT INTO users (username, email, mobile, user_type, password) VALUES ('$name', '$email', '$mobile', '$userType', '$hashedPassword')";
            if (mysqli_query($con, $query)) {
                header('Location: login.php');
                exit();
            } else {
                $error_message = "Registration failed. Please try again.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>INTERACTIVE LABORATORY SIMULATION - Sign Up</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
    <div class="main-page-wrapper">
        <div class="user-data-page clearfix d-md-flex">
            <div class="form-wrapper">
                <form id="registrationForm" method="POST" class="user-data-form mt-60 lg-mt-40">
                    <h2>Hi buddy, welcome <br> Sign Up!</h2>
                    <p class="header-info pt-20 pb-20 lg-pt-10 lg-pb-10">Already have an account? Login <a href="login.php">here</a></p>

                    <div class="row">
                        <div class="col-12">
                            <div class="input-group-meta mb-20">
                                <label>Name*</label>
                                <input type="text" name="name" id="name" placeholder="Enter your name" required>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="input-group-meta mb-20">
                                <label>Email*</label>
                                <input type="email" name="email" id="email" placeholder="Enter your email" required>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="input-group-meta mb-20">
                                <label>Password*</label>
                                <input type="password" name="password" id="password" placeholder="Enter Password" required>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="input-group-meta mb-20">
                                <label>Confirm Password*</label>
                                <input type="password" name="confirm_password" id="confirm_password" placeholder="Confirm Password" required>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="input-group-meta mb-20">
                                <label>Mobile Number*</label>
                                <input type="text" name="mobile" id="mobile" placeholder="Enter Mobile Number" maxlength="10" required pattern="^\d{10}$">
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="input-group-meta mb-20">
                                <label>User Type*</label>
                                <select name="user_type" id="user_type" required>
                                    <option value="CBSE">CBSE</option>
                                    <option value="SSLC">SSLC</option>
                                    <option value="HSC">HSC</option>
                                    <option value="UG">UG</option>
                                    <option value="PG">PG</option>
                                </select>
                            </div>
                        </div>

                        <!-- OTP Section -->
                        <div class="col-12">
                            <button type="button" id="sendOtpBtn" class="btn-eight w-100 mt-50 mb-40 lg-mt-30 lg-mb-30">Send OTP</button>
                        </div>

                        <!-- OTP Verification Section -->
                        <div id="otpVerificationForm" style="display: none;">
                            <div class="col-12">
                                <div class="input-group-meta mb-20">
                                    <label>Enter OTP*</label>
                                    <input type="text" id="otp" name="otp" placeholder="Enter OTP" required>
                                </div>
                            </div>
                            <div class="col-12">
                                <button type="submit" name="verify_otp" id="verifyOtpBtn" class="btn-eight w-100 mt-50 mb-40 lg-mt-30 lg-mb-30">Verify OTP and Register</button>
                            </div>
                        </div>

                        <?php
                        if (isset($error_message)) {
                            echo "<p style='color: red;'>$error_message</p>";
                        }
                        ?>

                        <p class="text-center copyright-text m0">Copyright @2025 INTERACTIVE LABORATORY SIMULATION.</p>
                    </div>
                </form>
            </div>
        </div>

        <button class="scroll-top">
            <i class="bi bi-arrow-up-short"></i>
        </button>
    </div>

    <script src="vendor/jquery.min.js"></script>
    <script src="js/theme.js"></script>
    <script>
        $(document).ready(function () {
            // Send OTP to user's mobile via WhatsApp
            $("#sendOtpBtn").on("click", function () {
                var mobile = $("#mobile").val();
                var userType = $("#user_type").val();
                var name = $("#name").val();
                var email = $("#email").val();

                // Validate mobile number (ensure it's 10 digits)
                if (!mobile.match(/^\d{10}$/)) {
                    alert('Please enter a valid 10-digit mobile number');
                    return;
                }

                // Check if password and confirm password match on the client side
                var password = $("#password").val();
                var confirmPassword = $("#confirm_password").val();
                if (password !== confirmPassword) {
                    alert("Password and Confirm Password do not match.");
                    return;
                }

                // Generate a random 6-digit OTP
                var otp = Math.floor(100000 + Math.random() * 900000);

                // Send OTP via AJAX to PHP backend
                $.ajax({
                    url: 'sendOtp.php',
                    type: 'POST',
                    data: { otp: otp, mobile: mobile },
                    success: function(response) {
                        console.log("Response from server:", response);  // Added logging to check the response
                        
                        try {
                            var result = JSON.parse(response);
                            if (result.status === 'success') {
                                // Open WhatsApp with the OTP link
                                var whatsappLink = result.whatsapp_link;
                                window.open(whatsappLink, '_blank');  // Open WhatsApp Web in a new tab

                                // Show OTP input for verification
                                $("#otpVerificationForm").show();
                            } else {
                                alert('Failed to send OTP: ' + result.message);
                            }
                        } catch (e) {
                            alert("Error parsing response: " + e.message);
                        }
                    },
                    error: function(xhr, status, error) {
                        alert('There was an error while sending the OTP. Please try again.');
                    }
                });
            });

        });
    </script>
</body>
</html>
